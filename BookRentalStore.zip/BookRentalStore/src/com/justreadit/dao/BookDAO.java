package com.justreadit.dao;

import com.justreadit.model.Book;

public class BookDAO {
	private static Book bookArray[]=new Book[100];

	public static boolean addBookDAO(Book bookObjAtDAO){
		boolean result=false;
		for(int i=0;i<bookArray.length;i++) {
			if(bookArray[i]==null) {
				bookArray[i]=bookObjAtDAO;
				result=true;
				break;
			}
		}
		System.out.println(bookArray[0]);
		return result;
	}
	public Book[] displayAllBooks() {
		Book bookArrayToDisplay[]=null;
		//Logic: Read bookArray and update bookArayToDisplay with book objects
		
		return bookArrayToDisplay;
	}
}
