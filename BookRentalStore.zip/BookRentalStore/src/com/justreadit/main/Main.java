package com.justreadit.main;
import java.util.Scanner;

import com.justreadit.view.BookView;
public class Main {
static Scanner scanner=new Scanner(System.in);
static void displaySubMenu() {
	System.out.println("1. Add Book");
	System.out.println("2. Display all books");
	System.out.println("Please enter your choice 1 or 2");
	int subMenuChoice=scanner.nextInt();
	scanner.nextLine();
	switch(subMenuChoice) {
	case 1:
		boolean result=BookView.addBookView();
		if(result)
			System.out.println("Book added successfully");
		break;
		default:
			System.out.println("Not a valid input");
	}
	
}
	public static void main(String[] args) {
	
		do {
			System.out.println("1. Start Application");
			System.out.println("2. Stop Application");
			System.out.println("Enter your choice: 1 or 2");
			int mainMenuChoice=scanner.nextInt();
			scanner.nextLine();
			switch(mainMenuChoice) {
			case 1:
				System.out.println("Sub Menu:");
				displaySubMenu();
				break;
			case 2:
				System.exit(0);
				break;
				default:
					System.out.println("You did not provide a valid input");
			
			}
			
			}while(true);
			

	}

}
