package com.justreadit.view;

import java.util.Scanner;

import com.justreadit.model.Book;
import com.justreadit.service.BookService;

public class BookView {
	static Scanner scanner = new Scanner(System.in);

	public static boolean addBookView() {
		boolean addResult = false;
		System.out.println("Enter book id");
		int bookId = scanner.nextInt();
		scanner.nextLine();
		System.out.println("Enter book name");
		String bookName = scanner.nextLine();
		System.out.println("Enter author name");
		String authorName = scanner.nextLine();
		System.out.println("Enter publisher name");
		String publisherName = scanner.nextLine();
		System.out.println("Enter per day rental charges");
		double rentalPrice = scanner.nextDouble();

		Book bookObjAtView=new Book(bookId,bookName,authorName,publisherName,rentalPrice);
		addResult=BookService.addBookService(bookObjAtView);
		return addResult;
	}

	public static void displayBook() {
		Book b1 = new Book(1, "OCJP", "Kathy's Serria", "XYZ Publisher", 50);
		Book b2 = new Book(1, "OCJP", "Kathy's Serria", "XYZ Publisher", 50);
		System.out.println(b1.hashCode());
		System.out.println(b2.hashCode());
		System.out.println(b1.equals(b2));
		System.out.println(b1);
	}

}
