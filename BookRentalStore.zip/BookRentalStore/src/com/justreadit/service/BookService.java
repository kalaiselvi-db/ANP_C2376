package com.justreadit.service;
import com.justreadit.dao.BookDAO;
import com.justreadit.model.Book;
public class BookService {
	// member variables, static variables, 
	//constructor
	//concrete method, static method
	
	public static boolean addBookService(Book bookObjAtService) {
		
		return BookDAO.addBookDAO(bookObjAtService);
	}

}
